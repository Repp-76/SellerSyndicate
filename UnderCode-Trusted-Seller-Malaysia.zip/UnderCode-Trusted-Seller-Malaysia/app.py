import os, re, sys, json, time, socket, signal, shutil, sqlite3, secrets, mimetypes, threading, traceback, subprocess
from contextlib import closing
from email import policy
from email.parser import BytesParser
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs

ROOT = Path(__file__).parent
DATA, UPLOADS, STATIC = ROOT / 'data', ROOT / 'uploads', ROOT / 'static'
DB = DATA / 'database.sqlite'
PUBLIC_PORT = int(os.environ.get('PUBLIC_PORT', 8980))
ADMIN_PORT = int(os.environ.get('ADMIN_PORT', 8089))
ADMIN_HOST = os.environ.get('ADMIN_HOST', '127.0.0.1')  # admin has no login, keep it local
MAX_IMG = 5 * 1024 * 1024
STATUSES = ('PENDING', 'APPROVED', 'REJECTED')
TS = "status TEXT DEFAULT 'PENDING', created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP"

SCHEMA = f"""
CREATE TABLE IF NOT EXISTS members(id INTEGER PRIMARY KEY, name TEXT, phone TEXT, role TEXT, whatsapp TEXT,
  telegram TEXT, description TEXT, image TEXT, verified INTEGER DEFAULT 0, {TS});
CREATE TABLE IF NOT EXISTS reports(id INTEGER PRIMARY KEY, name TEXT, phone TEXT, telegram TEXT, qr TEXT,
  face TEXT, description TEXT, reporter TEXT, {TS});
CREATE TABLE IF NOT EXISTS reviews(id INTEGER PRIMARY KEY, member_id INTEGER REFERENCES members(id) ON DELETE CASCADE,
  name TEXT, rating INTEGER, comment TEXT, {TS});
CREATE TABLE IF NOT EXISTS images(id INTEGER PRIMARY KEY, owner TEXT, owner_id INTEGER, file TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_reviews_member ON reviews(member_id, status);
CREATE INDEX IF NOT EXISTS idx_images_owner ON images(owner, owner_id);
"""


class ApiError(Exception):
    def __init__(self, code, msg):
        self.code, self.msg = code, msg


def connect():
    c = sqlite3.connect(DB, timeout=10)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    return c


def rows(sql, *a):
    with closing(connect()) as c:
        return [dict(r) for r in c.execute(sql, a)]


def run(sql, *a):
    with closing(connect()) as c:
        cur = c.execute(sql, a)
        c.commit()
        return cur.lastrowid


def clean(v, n):
    return re.sub(r'[\x00-\x08\x0b-\x1f]', '', str(v or '')).strip()[:n]


def save_image(data, sub):
    if len(data) > MAX_IMG:
        raise ApiError(400, 'Each image must be under 5 MB')
    if data[:3] == b'\xff\xd8\xff':
        ext = 'jpg'
    elif data[:8] == b'\x89PNG\r\n\x1a\n':
        ext = 'png'
    elif data[:4] == b'RIFF' and data[8:12] == b'WEBP':
        ext = 'webp'
    else:
        raise ApiError(400, 'Only JPG, PNG or WEBP images are allowed')
    name = f'{sub}/{secrets.token_hex(16)}.{ext}'
    (UPLOADS / name).write_bytes(data)
    return name


def one_image(files, field, sub):
    for n, data in files:
        if n == field:
            return save_image(data, sub)
    return None


def many_images(files, field, sub, owner, owner_id, limit):
    imgs = [d for n, d in files if n == field]
    if len(imgs) > limit:
        raise ApiError(400, f'Maximum {limit} images allowed')
    for d in imgs:
        run('INSERT INTO images(owner, owner_id, file) VALUES(?,?,?)', owner, owner_id, save_image(d, sub))


def purge_images(owner, owner_id):
    for r in rows('SELECT file FROM images WHERE owner=? AND owner_id=?', owner, owner_id):
        (UPLOADS / r['file']).unlink(missing_ok=True)
    run('DELETE FROM images WHERE owner=? AND owner_id=?', owner, owner_id)


def attach(items, owner):
    for it in items:
        it['images'] = [r['file'] for r in rows('SELECT file FROM images WHERE owner=? AND owner_id=? ORDER BY id', owner, it['id'])]
    return items


def paged(h, sql, tbl, where, args, order='id DESC', size=12):
    try:
        page = max(1, int(h.qs.get('page', 1)))
    except ValueError:
        page = 1
    total = rows(f'SELECT COUNT(*) n FROM {tbl} WHERE {where}', *args)[0]['n']
    items = rows(f'{sql} WHERE {where} ORDER BY {order} LIMIT ? OFFSET ?', *args, size, (page - 1) * size)
    return {'items': items, 'page': page, 'pages': max(1, -(-total // size)), 'total': total}


hits = {}


def limit(ip, key, n=8, per=3600):
    now = time.time()
    recent = [t for t in hits.get((ip, key), []) if now - t < per]
    if len(recent) >= n:
        raise ApiError(429, 'Too many attempts, please try again later')
    hits[(ip, key)] = recent + [now]


def telegram(v):
    v = clean(v, 200)
    if not v:
        return ''
    if v.startswith('http'):
        if not re.fullmatch(r'https?://[^\s<>"]+', v):
            raise ApiError(400, 'Invalid Telegram link')
        return v
    v = v.lstrip('@')
    if not re.fullmatch(r'\w{3,32}', v):
        raise ApiError(400, 'Invalid Telegram username')
    return v


def phone(v, required=True):
    v = clean(v, 20)
    if not v and not required:
        return ''
    if not re.fullmatch(r'\+?[\d\s-]{8,16}', v):
        raise ApiError(400, 'Invalid phone number')
    return v


def member_fields(f):
    name = clean(f.get('name'), 80)
    if len(name) < 2:
        raise ApiError(400, 'Name is required')
    role = clean(f.get('role'), 10).upper()
    if role not in ('SELLER', 'RESELLER'):
        raise ApiError(400, 'Role must be Seller or Reseller')
    wa = clean(f.get('whatsapp'), 200)
    if wa and not re.fullmatch(r'https?://[^\s<>"]+', wa):
        raise ApiError(400, 'WhatsApp link must start with http(s)://')
    return [name, phone(f.get('phone')), role, wa, telegram(f.get('telegram')), clean(f.get('description'), 500)]


PUBLIC, ADMIN = [], []


def route(lst, method, rx):
    def deco(fn):
        lst.append((method, rx, fn))
        return fn
    return deco


MEMBER_SQL = """SELECT m.id, m.name, m.phone, m.role, m.whatsapp, m.telegram, m.description, m.image, m.verified, m.status, m.created_at,
  (SELECT COUNT(*) FROM reviews r WHERE r.member_id=m.id AND r.status='APPROVED') AS reviews,
  (SELECT ROUND(AVG(rating),1) FROM reviews r WHERE r.member_id=m.id AND r.status='APPROVED') AS rating FROM members m"""


def like(q):
    return f'%{q}%'


@route(PUBLIC, 'GET', '/api/stats')
def stats(h):
    n = lambda sql: rows(sql)[0]['n']
    return {'members': n("SELECT COUNT(*) n FROM members WHERE status='APPROVED'"),
            'verified': n("SELECT COUNT(*) n FROM members WHERE status='APPROVED' AND verified=1"),
            'reviews': n("SELECT COUNT(*) n FROM reviews WHERE status='APPROVED'"),
            'reports': n("SELECT COUNT(*) n FROM reports WHERE status='APPROVED'")}


@route(PUBLIC, 'GET', '/api/members')
def list_members(h):
    where, args = ["m.status='APPROVED'"], []
    q = clean(h.qs.get('q'), 60)
    if q:
        where.append('(m.name LIKE ? OR m.phone LIKE ? OR m.telegram LIKE ?)')
        args += [like(q)] * 3
    f = h.qs.get('filter', 'all')
    cond = {'verified': 'm.verified=1', 'standard': 'm.verified=0', 'seller': "m.role='SELLER'", 'reseller': "m.role='RESELLER'"}
    if f in cond:
        where.append(cond[f])
    return paged(h, MEMBER_SQL, 'members m', ' AND '.join(where), args, 'm.verified DESC, m.id DESC')


@route(PUBLIC, 'GET', r'/api/members/(\d+)')
def get_member(h, id):
    m = rows(MEMBER_SQL + " WHERE m.id=? AND m.status='APPROVED'", id)
    if not m:
        raise ApiError(404, 'Profile not found')
    revs = rows("SELECT id, name, rating, comment, created_at FROM reviews WHERE member_id=? AND status='APPROVED' ORDER BY id DESC LIMIT 100", id)
    return {**m[0], 'items': attach(revs, 'review')}


@route(PUBLIC, 'GET', r'/api/scammers/(\d+)')
def get_scammer(h, id):
    r = rows("SELECT id, name, phone, telegram, qr, face, description, created_at FROM reports WHERE id=? AND status='APPROVED'", id)
    if not r:
        raise ApiError(404, 'Report not found')
    return attach(r, 'report')[0]


@route(PUBLIC, 'POST', '/api/apply')
def apply(h):
    limit(h.ip(), 'apply', 3)
    f, files = h.body()
    vals = member_fields(f)
    img = one_image(files, 'image', 'members')
    if not img:
        raise ApiError(400, 'Profile image is required')
    run("INSERT INTO members(name, phone, role, whatsapp, telegram, description, image) VALUES(?,?,?,?,?,?,?)", *vals, img)
    return {'ok': True}


@route(PUBLIC, 'GET', '/api/scammers')
def list_scammers(h):
    where, args = ["status='APPROVED'"], []
    q = clean(h.qs.get('q'), 60)
    if q:
        where.append('(name LIKE ? OR phone LIKE ? OR telegram LIKE ?)')
        args += [like(q)] * 3
    d = paged(h, 'SELECT id, name, phone, telegram, qr, face, description, created_at FROM reports', 'reports', ' AND '.join(where), args)
    attach(d['items'], 'report')
    return d


@route(PUBLIC, 'POST', '/api/report')
def report(h):
    limit(h.ip(), 'report', 3)
    f, files = h.body()
    name, tg = clean(f.get('name'), 80), telegram(f.get('telegram'))
    ph = phone(f.get('phone'), False)
    desc = clean(f.get('description'), 1500)
    if not (name or ph or tg):
        raise ApiError(400, 'Provide at least a name, phone number or Telegram username')
    if len(desc) < 10:
        raise ApiError(400, 'Please describe what happened (at least 10 characters)')
    qr, face = one_image(files, 'qr', 'reports'), one_image(files, 'face', 'reports')
    rid = run('INSERT INTO reports(name, phone, telegram, qr, face, description, reporter) VALUES(?,?,?,?,?,?,?)',
              name, ph, tg, qr, face, desc, clean(f.get('reporter'), 80))
    many_images(files, 'evidence', 'reports', 'report', rid, 5)
    return {'ok': True}


@route(PUBLIC, 'POST', r'/api/members/(\d+)/reviews')
def add_review(h, id):
    limit(h.ip(), 'review', 6)
    if not rows("SELECT id FROM members WHERE id=? AND status='APPROVED'", id):
        raise ApiError(404, 'Profile not found')
    f, files = h.body()
    name, comment = clean(f.get('name'), 40), clean(f.get('comment'), 1000)
    if len(name) < 2 or len(comment) < 3:
        raise ApiError(400, 'Name and comment are required')
    try:
        rating = int(f.get('rating'))
    except (TypeError, ValueError):
        rating = 0
    if not 1 <= rating <= 5:
        raise ApiError(400, 'Choose a rating from 1 to 5')
    if sum(1 for n, _ in files if n == 'images') > 3:
        raise ApiError(400, 'Maximum 3 images allowed')
    rid = run('INSERT INTO reviews(member_id, name, rating, comment) VALUES(?,?,?,?)', id, name, rating, comment)
    many_images(files, 'images', 'reviews', 'review', rid, 3)
    return {'ok': True}


# ---- admin ----

@route(ADMIN, 'GET', '/api/admin/overview')
def overview(h):
    n = lambda sql: rows(sql)[0]['n']
    return {'Total Sellers': n("SELECT COUNT(*) n FROM members WHERE status='APPROVED'"),
            'Verified Sellers': n("SELECT COUNT(*) n FROM members WHERE status='APPROVED' AND verified=1"),
            'Standard Sellers': n("SELECT COUNT(*) n FROM members WHERE status='APPROVED' AND verified=0"),
            'Pending Applications': n("SELECT COUNT(*) n FROM members WHERE status='PENDING'"),
            'Approved Scammers': n("SELECT COUNT(*) n FROM reports WHERE status='APPROVED'"),
            'Pending Scam Reports': n("SELECT COUNT(*) n FROM reports WHERE status='PENDING'"),
            'Total Reviews': n("SELECT COUNT(*) n FROM reviews WHERE status='APPROVED'"),
            'Pending Reviews': n("SELECT COUNT(*) n FROM reviews WHERE status='PENDING'")}


def status_of(h):
    s = h.qs.get('status', 'PENDING')
    if s not in STATUSES:
        raise ApiError(400, 'Invalid status')
    return s


@route(ADMIN, 'GET', '/api/admin/members')
def admin_members(h):
    return paged(h, MEMBER_SQL, 'members m', 'm.status=?', [status_of(h)], 'm.id DESC', 15)


@route(ADMIN, 'GET', '/api/admin/reports')
def admin_reports(h):
    d = paged(h, 'SELECT * FROM reports', 'reports', 'status=?', [status_of(h)], 'id DESC', 15)
    attach(d['items'], 'report')
    return d


@route(ADMIN, 'GET', '/api/admin/reviews')
def admin_reviews(h):
    d = paged(h, 'SELECT r.*, m.name AS member_name FROM reviews r JOIN members m ON m.id=r.member_id',
              'reviews r', 'r.status=?', [status_of(h)], 'r.id DESC', 15)
    attach(d['items'], 'review')
    return d


@route(ADMIN, 'POST', '/api/admin/members')
def admin_add_member(h):
    f, files = h.body()
    vals = member_fields(f)
    img = one_image(files, 'image', 'members')
    run("INSERT INTO members(name, phone, role, whatsapp, telegram, description, image, verified, status) VALUES(?,?,?,?,?,?,?,?,'APPROVED')",
        *vals, img, int(f.get('verified') == 'VERIFIED'))
    return {'ok': True}


def need(tbl, id):
    if not rows(f'SELECT id FROM {tbl} WHERE id=?', id):
        raise ApiError(404, 'Not found')


def decision(tbl):
    def fn(h, id):
        d, _ = h.body()
        need(tbl, id)
        st = {'approve': 'APPROVED', 'reject': 'REJECTED'}.get(d.get('action'))
        if not st:
            raise ApiError(400, 'Invalid action')
        if tbl == 'members' and st == 'APPROVED':
            if d.get('type') not in ('VERIFIED', 'STANDARD'):
                raise ApiError(400, 'Choose VERIFIED or STANDARD')
            run("UPDATE members SET status=?, verified=?, updated_at=CURRENT_TIMESTAMP WHERE id=?", st, int(d['type'] == 'VERIFIED'), id)
        else:
            run(f'UPDATE {tbl} SET status=?, updated_at=CURRENT_TIMESTAMP WHERE id=?', st, id)
        return {'ok': True}
    return fn


for _t in ('members', 'reports', 'reviews'):
    ADMIN.append(('POST', rf'/api/admin/{_t}/(\d+)/decision', decision(_t)))


@route(ADMIN, 'POST', r'/api/admin/members/(\d+)/update')
def update_member(h, id):
    d, _ = h.body()
    need('members', id)
    if 'verified' in d:
        run('UPDATE members SET verified=?, updated_at=CURRENT_TIMESTAMP WHERE id=?', int(bool(d['verified'])), id)
    if d.get('role') in ('SELLER', 'RESELLER'):
        run('UPDATE members SET role=?, updated_at=CURRENT_TIMESTAMP WHERE id=?', d['role'], id)
    return {'ok': True}


@route(ADMIN, 'DELETE', r'/api/admin/members/(\d+)')
def delete_member(h, id):
    need('members', id)
    for r in rows('SELECT id FROM reviews WHERE member_id=?', id):
        purge_images('review', r['id'])
    m = rows('SELECT image FROM members WHERE id=?', id)[0]
    if m['image']:
        (UPLOADS / m['image']).unlink(missing_ok=True)
    run('DELETE FROM members WHERE id=?', id)
    return {'ok': True}


@route(ADMIN, 'DELETE', r'/api/admin/reports/(\d+)')
def delete_report(h, id):
    need('reports', id)
    r = rows('SELECT qr, face FROM reports WHERE id=?', id)[0]
    for f in (r['qr'], r['face']):
        if f:
            (UPLOADS / f).unlink(missing_ok=True)
    purge_images('report', id)
    run('DELETE FROM reports WHERE id=?', id)
    return {'ok': True}


class Handler(BaseHTTPRequestHandler):
    routes, page, admin = [], 'index.html', False

    def log_message(self, *a):
        pass

    def ip(self):
        return self.headers.get('CF-Connecting-IP') or self.client_address[0]

    def reply(self, code, body, ctype='application/json'):
        if not isinstance(body, bytes):
            body = json.dumps(body).encode()
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Security-Policy', "default-src 'self'; img-src 'self' blob:; style-src 'self' 'unsafe-inline'")
        for k, v in self.extra:
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def body(self):
        n = int(self.headers.get('Content-Length') or 0)
        if n > 25 * 1024 * 1024:
            raise ApiError(413, 'Upload too large')
        raw, ct = self.rfile.read(n), self.headers.get('Content-Type', '')
        if ct.startswith('multipart/form-data'):
            msg = BytesParser(policy=policy.default).parsebytes(b'Content-Type: ' + ct.encode() + b'\r\n\r\n' + raw)
            fields, files = {}, []
            for p in msg.iter_parts():
                name = p.get_param('name', header='content-disposition')
                data = p.get_payload(decode=True) or b''
                if p.get_filename() is not None:
                    if data:
                        files.append((name, data))
                else:
                    fields[name] = data.decode('utf-8', 'replace').strip()
            return fields, files
        try:
            d = json.loads(raw or b'{}')
        except ValueError:
            raise ApiError(400, 'Invalid request body')
        return (d if isinstance(d, dict) else {}), []

    def serve_file(self, path):
        f = None
        if re.fullmatch(r'/static/[\w.-]+', path):
            f = STATIC / path[8:]
        elif re.fullmatch(r'/uploads/(members|reports|reviews)/[a-f0-9]{32}\.(jpg|png|webp)', path):
            f = UPLOADS / path[9:]
        else:
            f = STATIC / self.page
        if not f.is_file():
            raise ApiError(404, 'Not found')
        self.reply(200, f.read_bytes(), mimetypes.guess_type(f.name)[0] or 'application/octet-stream')

    def dispatch(self):
        url = urlparse(self.path)
        self.qs = {k: v[0] for k, v in parse_qs(url.query).items()}
        self.extra = []
        try:
            if url.path.startswith('/api/'):
                for method, rx, fn in self.routes:
                    m = re.fullmatch(rx, url.path)
                    if m and method == self.command:
                        return self.reply(200, fn(self, *m.groups()))
                raise ApiError(404, 'Not found')
            if self.command != 'GET':
                raise ApiError(405, 'Method not allowed')
            self.serve_file(url.path)
        except ApiError as e:
            self.reply(e.code, {'error': e.msg})
        except Exception:
            traceback.print_exc()
            self.reply(500, {'error': 'Something went wrong'})

    do_GET = do_POST = do_DELETE = dispatch


class PublicHandler(Handler):
    routes = PUBLIC


class AdminHandler(Handler):
    routes, page, admin = ADMIN, 'admin.html', True


def setup():
    for d in (DATA, UPLOADS / 'members', UPLOADS / 'reports', UPLOADS / 'reviews'):
        d.mkdir(parents=True, exist_ok=True)
    with closing(connect()) as c:
        c.executescript(SCHEMA)
        c.commit()


def port_ready(port, tries=50):
    for _ in range(tries):
        with socket.socket() as s:
            s.settimeout(0.2)
            if s.connect_ex(('127.0.0.1', port)) == 0:
                return True
        time.sleep(0.1)
    return False


def banner(url):
    line = '=' * 60
    print(f"\n{line}\n{'UnderCode Trusted Seller Malaysia'.center(60)}\n{line}\n\n{'YOUR LINK'.center(60)}\n\n"
          f"{'Ini link anda:'.center(60)}\n{url.center(60)}\n\n{line}\n", flush=True)


def start_tunnel():
    exe = shutil.which('cloudflared')
    if not exe:
        print('cloudflared is not installed or was not found.\n'
              '  Termux: pkg install cloudflared\n'
              '  Other:  https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/\n'
              f'The local site is still running on http://localhost:{PUBLIC_PORT}', flush=True)
        return None
    try:
        proc = subprocess.Popen([exe, 'tunnel', '--url', f'http://localhost:{PUBLIC_PORT}'],
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    except OSError as e:
        print(f'cloudflared could not be started: {e}', flush=True)
        return None

    def watch():
        found, tail = False, []
        for line in proc.stdout:
            tail = (tail + [line.strip()])[-5:]
            m = re.search(r'https://[a-z0-9-]+\.trycloudflare\.com', line)
            if m and not found:
                found = True
                banner(m.group(0))
        if not found:
            print('cloudflared stopped without giving a link:\n  ' + '\n  '.join(tail), flush=True)

    threading.Thread(target=watch, daemon=True).start()
    return proc


if __name__ == '__main__':
    setup()
    servers = []
    for cls, host, port in ((PublicHandler, '0.0.0.0', PUBLIC_PORT), (AdminHandler, ADMIN_HOST, ADMIN_PORT)):
        srv = ThreadingHTTPServer((host, port), cls)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        servers.append(srv)
    if not port_ready(PUBLIC_PORT):
        sys.exit(f'Public server did not start on port {PUBLIC_PORT}')
    print(f'Public site  http://localhost:{PUBLIC_PORT}\nAdmin panel  http://localhost:{ADMIN_PORT}', flush=True)
    tunnel = start_tunnel() if os.environ.get('TUNNEL', '1') != '0' else None
    stop = threading.Event()
    signal.signal(signal.SIGTERM, lambda *a: stop.set())
    try:
        stop.wait()
    except KeyboardInterrupt:
        pass
    finally:
        for srv in servers:
            srv.shutdown()
        if tunnel:
            tunnel.terminate()
            try:
                tunnel.wait(5)
            except subprocess.TimeoutExpired:
                tunnel.kill()
