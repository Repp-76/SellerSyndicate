$('#logo').innerHTML = icon('shield', 20);
const app = $('#app');
const TABS = [['overview', 'Overview'], ['sellers', 'Sellers'], ['applications', 'Applications'], ['reports', 'Scammer Reports'], ['scammers', 'Scammers'], ['reviews', 'Reviews']];
let state = { tab: 'overview', status: 'PENDING', page: 1 };

function shell() {
  $('#nav').innerHTML = TABS.map(([k, l]) => `<button data-k="${k}">${l}</button>`).join('');
  $('#nav').onclick = async e => {
    const k = e.target.dataset.k;
    if (!k) return;
    state = { tab: k, status: k === 'sellers' || k === 'scammers' ? 'APPROVED' : 'PENDING', page: 1 };
    view();
  };
  view();
}

async function view() {
  document.querySelectorAll('#nav button').forEach(b => b.classList.toggle('on', b.dataset.k === state.tab));
  try {
    if (state.tab === 'overview') {
      const d = await api('/api/admin/overview');
      app.innerHTML = `<h2>Overview</h2><div class="stats">${Object.entries(d).map(([l, n]) => `<div class="stat"><b>${n}</b><span>${l}</span></div>`).join('')}</div>`;
    } else await listView();
  } catch (e) { app.innerHTML = empty('ERROR', esc(e.message)); }
}

const KIND = { sellers: 'members', applications: 'members', reports: 'reports', scammers: 'reports', reviews: 'reviews' };
const STATUS_TAG = { PENDING: 'amber', APPROVED: 'green', REJECTED: 'red' };

async function listView() {
  const kind = KIND[state.tab], fixed = state.tab === 'sellers' || state.tab === 'scammers';
  const d = await api(`/api/admin/${kind}?` + new URLSearchParams({ status: state.status, page: state.page }));
  const add = state.tab === 'sellers' ? `<button class="btn primary" id="add">Add Seller/Reseller</button>` : '';
  const tabs = fixed ? '' : `<div class="tabs">${['PENDING', 'APPROVED', 'REJECTED'].map(s => `<button data-s="${s}" class="${state.status === s ? 'on' : ''}">${s[0] + s.slice(1).toLowerCase()}</button>`).join('')}</div>`;
  app.innerHTML = `<div class="row" style="justify-content:space-between;margin-bottom:12px"><h2 style="margin:0">${TABS.find(t => t[0] === state.tab)[1]} (${d.total})</h2>${add}</div>${tabs}
    <div id="items">${d.items.length ? d.items.map(ROW[kind]).join('') : empty('NOTHING HERE', 'No records with this status.')}</div>${pager(d)}`;
  app.onclick = onAction;
  if (add) $('#add').onclick = addSeller;
}

const statusTag = x => `<span class="tag ${STATUS_TAG[x.status]}">${x.status}</span>`;
const kv = (l, v) => v ? `<div class="kv">${l}: ${esc(v)}</div>` : '';
const actions = (x, id, kind) => {
  const b = (a, label, cls = '') => `<button class="btn sm ${cls}" data-a="${a}" data-id="${id}" data-kind="${kind}">${label}</button>`;
  if (x.status === 'PENDING') return b('approve', 'Approve', 'primary') + b('reject', 'Reject');
  if (kind === 'members' && x.status === 'APPROVED') return b('toggle', x.verified ? 'Set Standard' : 'Set Verified') + b('role', x.role === 'SELLER' ? 'Make Reseller' : 'Make Seller') + b('delete', 'Delete', 'danger');
  if (kind === 'reports' && x.status === 'APPROVED') return b('delete', 'Remove', 'danger');
  if (x.status === 'APPROVED') return b('reject', 'Reject');
  return b('approve', 'Approve');
};
const ROW = {
  members: m => `<div class="card item"><div class="head" style="display:flex;gap:12px;align-items:center">${avatar(m.image, m.name)}<div><h3>${esc(m.name)}</h3>
    <div class="tags">${statusTag(m)}<span class="tag">${m.role}</span>${m.verified ? `<span class="tag blue">Verified</span>` : '<span class="tag">Standard</span>'}</div></div></div>
    ${kv('Phone', m.phone)}${kv('WhatsApp', m.whatsapp)}${kv('Telegram', m.telegram)}${kv('Submitted', fmtDate(m.created_at))}${m.description ? `<p class="muted">${esc(m.description)}</p>` : ''}
    <div class="row">${actions(m, m.id, 'members')}</div></div>`,
  reports: r => `<div class="card item"><div class="meta"><h3>${esc(r.name || 'Unnamed')}</h3>${statusTag(r)}</div>${kv('Phone', r.phone)}${kv('Telegram', r.telegram)}${kv('Reporter', r.reporter)}${kv('Submitted', fmtDate(r.created_at))}
    <p class="muted">${esc(r.description)}</p>${thumbs([r.face, r.qr, ...r.images].filter(Boolean))}<div class="row">${actions(r, r.id, 'reports')}</div></div>`,
  reviews: r => `<div class="card item"><div class="meta"><b>${esc(r.name)} on ${esc(r.member_name)}</b>${statusTag(r)}</div><div>${stars(r.rating)}</div>
    <p class="muted">${esc(r.comment)}</p>${thumbs(r.images)}${kv('Date', fmtDate(r.created_at))}<div class="row">${actions(r, r.id, 'reviews')}</div></div>`
};

async function onAction(e) {
  const b = e.target.closest('[data-a],[data-s],[data-pg]');
  if (!b) return;
  if (b.dataset.s) { state.status = b.dataset.s; state.page = 1; return view(); }
  if (b.dataset.pg) { state.page = +b.dataset.pg; return view(); }
  const { a, id, kind } = b.dataset, base = `/api/admin/${kind}/${id}`;
  try {
    if (a === 'approve' && kind === 'members') {
      const type = await modal('Choose Approval Type', 'Verified members get a badge in the directory.', [{ label: 'Cancel', value: null }, { label: 'Standard', value: 'STANDARD' }, { label: 'Verified', value: 'VERIFIED', cls: 'primary' }]);
      if (!type) return;
      await api(base + '/decision', { json: { action: 'approve', type } });
    } else if (a === 'approve' || a === 'reject') await api(base + '/decision', { json: { action: a } });
    else if (a === 'toggle') await api(base + '/update', { json: { verified: b.textContent.includes('Verified') } });
    else if (a === 'role') await api(base + '/update', { json: { role: b.textContent.includes('Reseller') ? 'RESELLER' : 'SELLER' } });
    else if (a === 'delete') {
      if (!await modal('Delete permanently?', 'This also removes related images and cannot be undone.', [{ label: 'Cancel', value: false }, { label: 'Delete', value: true, cls: 'danger' }])) return;
      await api(base, { method: 'DELETE' });
    }
    toast('Saved');
    view();
  } catch (x) { toast(x.message, 1); }
}

function addSeller() {
  app.innerHTML = `<div class="page narrow"><a class="back" href="#" id="bk">${icon('back', 16)}Back</a><h2>Add Seller/Reseller</h2><form class="card form" id="f">
    ${fld('Name', 'name', { req: 1 })}${fld('Phone', 'phone', { req: 1, type: 'tel' })}${fld('Role', 'role', { type: 'select', opts: [['SELLER', 'Seller'], ['RESELLER', 'Reseller']] })}
    ${fld('Profile image', 'image', { type: 'file' })}${fld('WhatsApp link', 'whatsapp')}${fld('Telegram', 'telegram')}${fld('Description', 'description', { type: 'textarea', max: 500 })}
    ${fld('Status', 'verified', { type: 'select', opts: [['STANDARD', 'Standard'], ['VERIFIED', 'Verified']] })}<button class="btn primary">Save</button></form></div>`;
  $('#bk').onclick = e => { e.preventDefault(); view(); };
  $('#f').onsubmit = async e => {
    e.preventDefault();
    try { await api('/api/admin/members', { method: 'POST', body: new FormData(e.target) }); toast('Seller added'); view(); } catch (x) { toast(x.message, 1); }
  };
}

shell();
