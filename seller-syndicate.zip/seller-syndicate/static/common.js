const ICONS = {
  star: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
  shield: '<path d="M12 3l8 3v6c0 4.5-3.2 8-8 9-4.8-1-8-4.5-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
  check: '<path d="M5 12l4 4 10-10"/>',
  arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  back: '<path d="M19 12H5M11 6l-6 6 6 6"/>',
  search: '<circle cx="11" cy="11" r="6"/><path d="M20 20l-4-4"/>',
  chat: '<path d="M4 5h16v11H9l-5 4z"/>',
  send: '<path d="M21 4L3 11l6 2 2 6z"/>',
  alert: '<path d="M12 4l9 16H3zM12 10v4M12 17v.5"/>'
};
const icon = (n, s = 18) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="${n === 'star' ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${ICONS[n]}</svg>`;
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const img = f => '/uploads/' + f;
const fmtDate = s => new Date(s.replace(' ', 'T') + 'Z').toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });

async function api(url, opt = {}) {
  if (opt.json) { opt = { method: opt.method || 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(opt.json) }; }
  const r = await fetch(url, opt);
  let d = {};
  try { d = await r.json(); } catch {}
  if (!r.ok) { const e = new Error(d.error || 'Request failed'); e.status = r.status; throw e; }
  return d;
}

function toast(msg, bad) {
  const t = document.createElement('div');
  t.className = 'toast' + (bad ? ' bad' : '');
  t.textContent = msg;
  document.body.append(t);
  setTimeout(() => t.remove(), 3500);
}

function modal(title, html, buttons) {
  return new Promise(res => {
    const o = document.createElement('div');
    o.className = 'overlay';
    o.innerHTML = `<div class="modal"><h3>${esc(title)}</h3><div class="muted">${html}</div><div class="row end">${buttons.map((b, i) => `<button class="btn ${b.cls || ''}" data-i="${i}">${esc(b.label)}</button>`).join('')}</div></div>`;
    o.onclick = e => {
      const b = e.target.closest('[data-i]');
      if (b) { o.remove(); res(buttons[b.dataset.i].value); }
      else if (e.target === o) { o.remove(); res(null); }
    };
    document.body.append(o);
  });
}

const stars = n => [1, 2, 3, 4, 5].map(i => `<span class="star ${i <= Math.round(n || 0) ? '' : 'off'}">${icon('star', 15)}</span>`).join('');
const avatar = (f, name) => f ? `<img class="avatar" src="${img(f)}" alt="">` : `<div class="avatar ph">${esc((name || '?')[0].toUpperCase())}</div>`;
const thumbs = list => list.length ? `<div class="thumbs">${list.map(f => `<a href="${img(f)}" target="_blank" rel="noopener"><img src="${img(f)}" alt="" loading="lazy"></a>`).join('')}</div>` : '';
const pager = d => d.pages > 1 ? `<div class="pager"><button class="btn sm" data-pg="${d.page - 1}" ${d.page <= 1 ? 'disabled' : ''}>Prev</button><span>${d.page} / ${d.pages}</span><button class="btn sm" data-pg="${d.page + 1}" ${d.page >= d.pages ? 'disabled' : ''}>Next</button></div>` : '';
const empty = (t, s) => `<div class="empty">${icon('search', 28)}<b>${t}</b><span>${s}</span></div>`;

function fld(label, name, o = {}) {
  const req = o.req ? ' required' : '';
  if (o.type === 'select') return `<label>${label}<select name="${name}">${o.opts.map(v => `<option value="${v[0]}">${v[1]}</option>`).join('')}</select></label>`;
  if (o.type === 'textarea') return `<label>${label}<textarea name="${name}" rows="4" maxlength="${o.max || 1500}"${req}></textarea></label>`;
  if (o.type === 'file') return `<label>${label}<input type="file" name="${name}" accept="image/jpeg,image/png,image/webp"${o.multiple ? ' multiple' : ''}${req}></label>`;
  return `<label>${label}<input name="${name}" type="${o.type || 'text'}" maxlength="${o.max || 200}"${o.ph ? ` placeholder="${o.ph}"` : ''}${req}></label>`;
}
