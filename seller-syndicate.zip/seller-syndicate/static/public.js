$('#logo').innerHTML = icon('shield', 20);
const app = $('#app');
const routes = { '': home, directory, report: reportPage, apply: applyPage, m: profile };

function nav() {
  const [r, id] = location.hash.slice(2).split('/');
  document.querySelectorAll('nav a').forEach(a => a.classList.toggle('on', a.dataset.r === (r || '')));
  window.scrollTo(0, 0);
  (routes[r] || home)(id);
}
addEventListener('hashchange', nav);

const waLink = m => m.whatsapp || (m.phone ? 'https://wa.me/' + m.phone.replace(/\D/g, '').replace(/^0/, '60') : '');
const tgLink = m => m.telegram ? (m.telegram.startsWith('http') ? m.telegram : 'https://t.me/' + m.telegram) : '';
const ext = (href, cls, ic, label) => `<a class="btn ${cls}" href="${esc(href)}" target="_blank" rel="noopener noreferrer">${icon(ic, 16)}${label}</a>`;

async function home() {
  const s = await api('/api/stats').catch(() => ({ members: 0, verified: 0, reviews: 0, reports: 0 }));
  const cards = [['Total Members', s.members], ['Verified Members', s.verified], ['Total Reviews', s.reviews], ['Scam Reports', s.reports]];
  app.innerHTML = `<section class="hero"><p class="eyebrow">Community trust directory</p><h1>Seller Syndicate</h1>
    <p class="lead">Check a seller or reseller before you deal. Read reviews from other buyers and look up scammers reported to us.</p>
    <div class="row center"><a class="btn primary" href="#/directory">Browse Directory ${icon('arrow', 16)}</a><a class="btn" href="#/report">Report Scammer</a><a class="btn" href="#/apply">Apply Seller/Reseller</a></div></section>
    <section class="stats">${cards.map(([l, n]) => `<div class="stat"><b>${n}</b><span>${l}</span></div>`).join('')}</section>`;
}

const memberCard = m => `<article class="card member">
  <div class="head">${avatar(m.image, m.name)}<div><h3>${esc(m.name)}</h3><div class="tags">
    ${m.verified ? `<span class="tag blue">${icon('shield', 12)}Verified</span>` : ''}<span class="tag">${m.role}</span>
    ${m.verified && m.rating >= 4.5 ? `<span class="tag green">${icon('check', 12)}Trusted</span>` : ''}</div></div></div>
  <div class="rate">${stars(m.rating)}<span>${m.reviews ? m.rating.toFixed(1) + ' · ' + m.reviews + (m.reviews > 1 ? ' reviews' : ' review') : 'No reviews yet'}</span></div>
  ${m.description ? `<p class="desc">${esc(m.description)}</p>` : ''}
  <div class="row"><a class="btn" href="#/m/${m.id}">View Profile</a>${contacts(m)}</div></article>`;

const contacts = m => (waLink(m) ? ext(waLink(m), 'primary', 'chat', 'WhatsApp') : '') + (tgLink(m) ? ext(tgLink(m), '', 'send', 'Telegram') : '');

const scamCard = s => `<article class="card scam item"><div class="meta"><h3>${esc(s.name || 'Unnamed')}</h3><span class="tag red">${icon('alert', 12)}Reported Scam</span></div>
  <dl>${s.phone ? `<dt>Phone</dt><dd>${esc(s.phone)}</dd>` : ''}${s.telegram ? `<dt>Telegram</dt><dd>${esc(s.telegram)}</dd>` : ''}<dt>Reported</dt><dd>${fmtDate(s.created_at)}</dd></dl>
  <p class="muted">${esc(s.description)}</p>${thumbs([s.face, s.qr, ...s.images].filter(Boolean))}
  <span class="kv">Approved report. Reviewed by admins for listing, not a legal finding.</span></article>`;

function directory() {
  const st = { tab: 'sellers', q: '', f: 'all', page: 1 };
  app.innerHTML = `<div class="page"><h2>Directory</h2>
    <div class="tabs" id="tabs"><button data-t="sellers">Sellers &amp; Resellers</button><button data-t="scammers">Scammer Reports</button></div>
    <div class="search">${icon('search')}<input id="q" placeholder="Search name, phone or Telegram" maxlength="60"></div>
    <div class="chips" id="chips"></div><div class="grid" id="list"></div><div id="pg"></div></div>`;
  const filters = ['all', 'verified', 'standard', 'seller', 'reseller'];
  async function load() {
    $('#tabs').querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.t === st.tab));
    $('#chips').innerHTML = st.tab === 'sellers' ? filters.map(f => `<button data-f="${f}" class="${st.f === f ? 'on' : ''}">${f[0].toUpperCase() + f.slice(1)}</button>`).join('') : '';
    $('#list').innerHTML = '<p class="muted">Loading...</p>';
    try {
      const sellers = st.tab === 'sellers';
      const d = await api(`/api/${sellers ? 'members' : 'scammers'}?` + new URLSearchParams({ q: st.q, filter: st.f, page: st.page }));
      $('#list').innerHTML = d.items.length ? d.items.map(sellers ? memberCard : scamCard).join('') : (sellers ? empty('NO SELLERS FOUND', 'Try a different search or filter.') : empty('NO SCAM REPORTS FOUND', 'Nothing matches your search.'));
      $('#pg').innerHTML = pager(d);
    } catch (e) { $('#list').innerHTML = empty('COULD NOT LOAD', esc(e.message)); }
  }
  let timer;
  $('#q').oninput = e => { clearTimeout(timer); timer = setTimeout(() => { st.q = e.target.value.trim(); st.page = 1; load(); }, 300); };
  $('.page').onclick = e => {
    const b = e.target.closest('[data-t],[data-f],[data-pg]');
    if (!b) return;
    if (b.dataset.t) { st.tab = b.dataset.t; st.page = 1; }
    if (b.dataset.f) { st.f = b.dataset.f; st.page = 1; }
    if (b.dataset.pg) st.page = +b.dataset.pg;
    load();
  };
  load();
}

async function profile(id) {
  let m;
  try { m = await api('/api/members/' + id); } catch { app.innerHTML = empty('PROFILE NOT FOUND', '<a href="#/directory">Back to directory</a>'); return; }
  app.innerHTML = `<div class="page narrow"><a class="back" href="#/directory">${icon('back', 16)}Directory</a>
    <div class="card member" style="margin-bottom:24px">${memberCard(m).replace(/^<article class="card member">|<\/article>$/g, '')}</div>
    <h2>Reviews (${m.items.length})</h2><div id="revs">${m.items.length ? m.items.map(r => `<div class="card review"><div class="top"><b>${esc(r.name)}</b><span class="muted">${fmtDate(r.created_at)}</span></div>
      <div>${stars(r.rating)}</div><p>${esc(r.comment)}</p>${thumbs(r.images)}</div>`).join('') : empty('NO REVIEWS YET', 'Be the first to review this seller.')}</div>
    <div class="card" id="rv" style="margin-top:20px"></div></div>`;
  const box = $('#rv');
  let name = '';
  const step1 = () => {
    box.innerHTML = `<h3>Leave a review</h3><p class="muted">Reviews are checked by admins before they appear.</p><div class="form"><label>Your name<input id="rn" maxlength="40"></label><button class="btn primary" id="ok">OK</button></div>`;
    $('#ok').onclick = () => { name = $('#rn').value.trim(); name.length < 2 ? toast('Enter your name first', 1) : step2(); };
  };
  const step2 = () => {
    let rating = 0;
    box.innerHTML = `<h3>Review as ${esc(name)}</h3><div class="form"><div class="starpick" id="sp">${[1, 2, 3, 4, 5].map(n => `<button type="button" data-n="${n}">${icon('star', 28)}</button>`).join('')}</div>
      <label>Comment<textarea id="rc" rows="4" maxlength="1000"></textarea></label>
      <label>Evidence images (max 3)<input type="file" id="ri" accept="image/jpeg,image/png,image/webp" multiple></label><div class="thumbs" id="pv"></div>
      <button class="btn primary" id="sb" disabled>Submit Review</button></div>`;
    const ready = () => $('#sb').disabled = !(rating && $('#rc').value.trim().length >= 3);
    $('#sp').onclick = e => { const b = e.target.closest('[data-n]'); if (!b) return; rating = +b.dataset.n; [...$('#sp').children].forEach((x, i) => x.classList.toggle('on', i < rating)); ready(); };
    $('#rc').oninput = ready;
    $('#ri').onchange = e => {
      if (e.target.files.length > 3) { toast('Maximum 3 images allowed', 1); e.target.value = ''; }
      $('#pv').innerHTML = [...e.target.files].map(f => `<img src="${URL.createObjectURL(f)}" alt="">`).join('');
    };
    $('#sb').onclick = async () => {
      const fd = new FormData();
      fd.append('name', name); fd.append('rating', rating); fd.append('comment', $('#rc').value);
      [...$('#ri').files].forEach(f => fd.append('images', f));
      $('#sb').disabled = true;
      try { await api(`/api/members/${id}/reviews`, { method: 'POST', body: fd }); box.innerHTML = `<div class="empty">${icon('check', 28)}<b>REVIEW SUBMITTED</b><span>It will appear once an admin approves it.</span></div>`; }
      catch (e) { toast(e.message, 1); $('#sb').disabled = false; }
    };
  };
  step1();
}

function formPage(o) {
  app.innerHTML = `<div class="page narrow"><h2>${o.title}</h2><p class="muted">${o.intro}</p><form class="card form" id="f">${o.fields}<button class="btn primary" id="sb">${o.btn}</button></form></div>`;
  $('#f').onsubmit = async e => {
    e.preventDefault();
    $('#sb').disabled = true;
    try {
      await api(o.url, { method: 'POST', body: new FormData(e.target) });
      $('.page').innerHTML = `<div class="card empty">${icon('check', 28)}<b>${o.done[0]}</b><span>${o.done[1]}</span><a class="btn" href="#/directory">Back to directory</a></div>`;
    } catch (err) { toast(err.message, 1); $('#sb').disabled = false; }
  };
}

const applyPage = () => formPage({
  title: 'Apply as Seller or Reseller', btn: 'Submit Application', url: '/api/apply',
  intro: 'Applications are reviewed by admins before your profile is listed.',
  fields: fld('Full name', 'name', { req: 1, max: 80 }) + fld('Phone number', 'phone', { req: 1, type: 'tel', ph: '0123456789' }) +
    fld('Profile image', 'image', { type: 'file', req: 1 }) + fld('I am a', 'role', { type: 'select', opts: [['SELLER', 'Seller'], ['RESELLER', 'Reseller']] }) +
    fld('WhatsApp channel link (optional)', 'whatsapp', { ph: 'https://' }) + fld('Telegram channel link or username (optional)', 'telegram') +
    fld('Description (optional)', 'description', { type: 'textarea', max: 500 }),
  done: ['APPLICATION SENT', 'An admin will review it shortly.']
});

const reportPage = () => formPage({
  title: 'Report a Scammer', btn: 'Submit Report', url: '/api/report',
  intro: 'Only fill in what you know. Reports are checked by admins before anything is published. Do not include private details of unrelated people.',
  fields: fld('Scammer name', 'name', { max: 80 }) + fld('Phone number', 'phone', { type: 'tel' }) + fld('Telegram username', 'telegram') +
    fld('Scammer QR code', 'qr', { type: 'file' }) + fld('Scammer face / profile image', 'face', { type: 'file' }) +
    fld('Additional evidence images (max 5)', 'evidence', { type: 'file', multiple: 1 }) +
    fld('Report details', 'description', { type: 'textarea', req: 1 }) + fld('Your name or contact (optional, not public)', 'reporter', { max: 80 }),
  done: ['REPORT SENT', 'Thank you. An admin will review it before it is listed.']
});

nav();
